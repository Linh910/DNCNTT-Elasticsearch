# Các tin tức giả được dẫn và nguồn

Cấu trúc của phần lưu trữ tin tức giả: __{Tên file}: {Tiêu đề/Link} - {Lý do phân loại}__. Trong một số tin tức sẽ có thêm phần _relevant_\__site_"

VFND_Ac_Fake_0: [Con gái chính là người tình kiếp trước của cha](https://2sao.vn/loat-anh-sieu-yeu-chung-minh-con-gai-la-nguoi-tinh-kiep-truoc-cua-cha-i-154763.html): Tiền đề sai

VFND_Ac_Fake_1: [Thủ tướng Abe cúi đầu xin lỗi vì hành động phi thể thao của tuyển Nhật](http://binhluan.biz/thu-tuong-abe-cui-dau-xin-loi-vi-hanh-dong-phi-the-thao-cua-tuyen-nhat.html) - So sánh với nguồn tin chuẩn, hình ảnh sai lệch

VFND_Ac_Fake_2: [Thủ tướng Nhật cúi đầu xin lỗi vì tinh thần phi thể thao của đội bóng](http://www.ipick.vn/bai-viet/thu-tuong-nhat-cui-dau-xin-loi-vi-tinh-than-phi-the-thao-cua-doi-bong) - Nguồn từ bài viết được phân loại GIẢ

VFND_Ac_Fake_3: [Choáng! Cơ trưởng đeo khăn quàng quẩy banh nóc trên sân khấu trường!!!](http://tintucqpvn.net/choang-co-truong-deo-khan-quang-quay-banh-noc-tren-san-khau-truong.html) - Tiêu đề và nội dung không khớp

VFND_Ac_Fake_4: [Chưa bao giờ nhạc Kpop lại dễ hát đến thế!!!](http://tintucqpvn.net/chua-bao-gio-nhac-kpop-lai-de-hat-den-the.html) - Tiêu đề và nội dung không khớp, tiêu đề kích động

VFND_Ac_Fake_5: [Đại học Hutech sẽ áp dụng cải cách \"Tiếq Việt\" vào năm học 2018?](http://www.gioitreviet.net/dai-hoc-hutech-se-ap-dung-cai-cach-tieq-viet-vao-nam-hoc-2018-59528.html) - Bài viết xác nhận tin tức thật VFND_Ac_Real_5, kết hợp nhiều bài viết khác nhau

VFND_Ac_Fake_6: [Cười vỡ bụng khi tiếng CẢI CÁCH \"vuông tròn\" xâm nhập chợ búa, các mẹ sử dụng chuyên nghiệp](https://giadinhtiepthi.com/cuoi-vo-bung-khi-tieng-cai-cach-vuong-tron-xam-nhap-cho-bua-cac-su-dung-chuyen-nghiep/) - Tiêu đề và nội dung kích động người đọc

VFND_Ac_Fake_7: [Chia sẻ thẳng thắn vụ việc 25000 USD và cải cách giáo dục, rốt cục là “sân si” hay là “ganh tị”](https://giadinhtiepthi.com/chia-se-thang-than-vu-viec-25000-usd-va-cai-cach-giao-duc-rot-cuc-la-san-si-hay-la-ganh-ti/) - Nội dung không liên quan đến tiêu đề và nội dung chung

VFND_Ac_Fake_8: [Hại não với Vọng Cổ mang tên Vuông Tròn Tam Giác!](http://tintucqpvn.net/hai-nao-voi-vong-co-mang-ten-vuong-tron-tam-giac.html) - Tiêu đề và nội dung không khớp, tiêu đề kích động

VFND_Ac_Fake_9: [Kinh hoàng bé gái bị chó nhà tấn công, cắn vào khắp người gây phẫn nộ](http://tintucqpvn.net/kinh-hoang-be-gai-bi-cho-nha-tan-cong-can-vao-khap-nguoi-gay-phan-no.html) - Nội dung và tiêu đề không liên quan

VFND_Ac_Fake_10: [Bức vẽ giúp bạn đánh giá mức độ stress của bản thân](https://suckhoe.vnexpress.net/tin-tuc/tu-van/buc-ve-giup-ban-danh-gia-muc-do-stress-cua-ban-than-3840208.html) - bài viết mang thông tin giả, được nhóm kiểm chứng trong [post sau](https://zefro.wordpress.com/2018/11/20/khi-hinh-ban-nhin-khong-nhu-dieu-ban-doc-lat-tay-tin-gia-1/)

VFND_Ac_Fake_10: [Bức vẽ giúp bạn đánh giá mức độ stress của bản thân](https://suckhoe.vnexpress.net/tin-tuc/tu-van/buc-ve-giup-ban-danh-gia-muc-do-stress-cua-ban-than-3840208.html) - như VFND_Ac_Fake_10

VFND_Ac_Fake_11: [KHẨN CẤP: Hàng loạt trẻ em nhập viện vì ngộ độc thịt lợn có chứa thuốc an thần](http://phapluat.news/khan-cap-hang-loat-tre-em-nhap-vien-vi-ngo-doc-thit-lon-co-chua-thuoc.html)

VFND_Ac_Fake_12: [Không đủ tiền tiêu hủy, Chi cục Thú y đề nghị Thảo Cầm Viên mua lại chó hoang làm mồi cho sư tử](http://phapluat.news/khong-du-tien-tieu-huy-chi-cuc-thu-y-de-nghi-thao-cam-vien-mua-lai-cho-hoang-lam-moi-cho-su-tu.html)

VFND_Ac_Fake_13: [KHẨN CẤP: Xuất hiện xe bắt chó giả ở TP.HCM](http://autoxe.net/doi-song/khan-cap-xuat-hien-xe-bat-cho-gia-o-tp-hcm.html)

VFND_Ac_Fake_14: [Đề xuất cấm tất cả công chức Hà Nội đổ xăng tại trạm xăng Nhật](http://phapluat.news/de-xuat-cam-tat-ca-cong-chuc-ha-noi-xang-tai-tram-xang-nhat.html)

VFND_Ac_Fake_15: [Thanh niên 24 bỗng hóa người rắn sau 1 đêm, da dẻ nứt toác đen xì ai nhìn cũng hã-i](http://tintucqpvn.net/thanh-nien-24-bong-hoa-nguoi-ran-sau-1-dem-da-de-nut-toac-den-xi-ai-nhin-cung-ha-i.html)

VFND_Ac_Fake_16: [5 mẹo 'thần thánh' đánh bay mụn trong một đêm](https://thegioitre.vn/5-meo-than-thanh-danh-bay-mun-trong-mot-dem-47385.html)

VFND_Ac_Fake_17: [Dân tình "tá hỏa" với hình ảnh "mát mẻ", phì phèo thuốc lá của Erik sau bao nhiêu năm làm "trai ngoan"](https://thegioitre.vn/dan-tinh-ta-hoa-voi-hinh-anh-mat-me-phi-pheo-thuoc-la-cua-erik-sau-bao-nhieu-nam-lam-trai-ngoan-61821.html)

VFND_Ac_Fake_18: [Hollywood sẽ làm siêu phẩm về Tết Mậu Thân 1968 ở Huế?](https://www.ipick.vn/bai-viet/hollywood-se-lam-sieu-pham-ve-tet-mau-than-1968-o-hue)

VFND_Ac_Fake_19: [Hoạ sỹ khuyết tật Lê Minh Châu trở thành người Việt đầu tiên có tên trên Đại lộ Danh vọng Hollywood](http://baoangiang.com.vn/hoa-sy-khuyet-tat-le-minh-chau-tro-thanh-nguoi-viet-dau-tien-co-ten-tren-dai-lo-danh-vong-hollywood-a234717.html)

VFND_Ac_Fake_20: [Bà cụ 92 vẫn mang thai, tá hỏa đưa đi khám mới phát hiện sự thật động trời sau 50 năm](http://thoibao.today/paper/ba-cu-92-van-mang-thai-ta-hoa-dua-di-kham-moi-phat-hien-su-that-dong-troi-sau-50-nam-2316227)

VFND_Ac_Fake_21: [Phát hiện sự thật động trời sau việc chồng “không.. được”](http://thoibao.today/paper/phat-hien-su-that-dong-troi-sau-viec-chong-khong-duoc-1736407)

VFND_Ac_Fake_22: [VIDEO: Xót xa nhìn cảnh cụ bà 87 tuổi co ro trong tấm chiếu cũ giữa mùa đông rét buốt](http://haiduong.tintuc.vn/goc-hai-duong/video-xot-xa-nhin-canh-cu-ba-87-tuoi-co-ro-trong-tam-chieu-cu-giua-mua-dong-ret-buot.html)

VFND_Ac_Fake_23: [TẢI NGAY APP 567LIVE NGẮM GÁI XINH NÓNG BỎNG](https://vinaexpress.com.vn/tai-ngay-app-567live-ngam-gai-xinh-nong-bong/)

VFND_Ac_Fake_24: [Bi kịch ngoại tình với bố chồng](http://sorry.vn/blog/read/131-Bi-kich-ngoai-tinh-voi-bo-chong.html)

VFND_Ac_Fake_25: [Đức từ chối cấp Visa cho đoàn công tác nhà nước, tạm ngừng cấp Visa cho du học sinh Việt Nam?](https://thoibao.de/duc-tu-choi-cap-visa-cho-doan-cong-tac-nha-nuoc-tam-ngung-cap-visa-cho-du-hoc-sinh-viet-nam)

VFND_Ac_Fake_26: [Đại sứ quán Đức tại Hà Nội từ chối cấp Visa cho lao động Việt Nam sang học nghề điều dưỡng](https://thoibao.de/dai-su-quan-duc-o-ha-noi-tu-choi-cap-visa-cho-lao-dong-viet-nam-sang-hoc-nghe-dieu-duong)

VFND_Ac_Fake_27: [Sự thật kinh hoàng về nước Mỹ qua lời kể của một du học sinh Trung Quốc](http://baonuocmy.com/doi-song/su-that-kinh-hoang-ve-nuoc-my-qua-loi-ke-cua-mot-du-hoc-sinh-trung-quoc-78613.html?fbclid=IwAR0JCXj-9pg-tzhBOT_GJqKzKFUkyXmbVqhkl4p6-R3i0tf6rCwTvCv5F1M)

VFND_Ac_Fake_28: [Rùa biển sa lưới ‘vươn cổ cúi lạy’, ông chủ bèn mua rồi phóng sinh, 16 năm sau chú rùa quay lại trả ơn](http://thoibao.today/paper/rua-bien-sa-luoi-vuon-co-cui-lay-ong-chu-ben-mua-roi-phong-sinh-16-nam-sau-chu-rua-quay-lai-tra-on-1937316)

VFND_Ac_Fake_29: [Khám phá sửng sốt về trí nhớ "như thần" của động vật](http://thoibao.today/paper/kham-pha-sung-sot-ve-tri-nho-nhu-than-cua-dong-vat-3668946)

VFND_Ac_Fake_30: [Những món ăn "thần kỳ" giúp sĩ tử "thi đâu đậu đó"](http://thoibao.today/paper/nhung-mon-an-than-ky-giup-si-tu-thi-dau-dau-do-2134905)

VFND_Ac_Fake_31: ['Thần dược' mùa đông](http://thoibao.today/paper/than-duoc-mua-dong-chua-bach-benh-ma-nhieu-nguoi-tho-o-1398946)

VFND_Ac_Fake_32: [Đứng bán nem chua rán, gái xinh khiến dân mạng tá hỏa vì “dụng cụ nguy hiểm” đặt ngay dưới vòng 1](http://tinvn.info/dung-ban-nem-chua-ran-gai-xinh-khien-dan-mang-ta-hoa-vi-dung-cu-nguy-hiem-dat-ngay-duoi-vong-1.html)

VFND_Ac_Fake_33: [Đi cả đêm mới về, bà mẹ tá hoả thấy mặt con bị cắt nát kinh dị và sự thật sốc tận não đằng sau](http://tinvn.info/di-ca-dem-moi-ve-ba-me-ta-hoa-thay-mat-con-bi-cat-nat-kinh-di-va-su-that-soc-tan-nao-dang-sau.html)

VFND_Ac_Fake_34: [Khoe ảnh đẹp không tỳ vết nhưng Ngọc Trinh khiến người nhìn tá hỏa khi phát hiện ra phần ‘dị dạng’ này!](http://tinvn.info/khoe-anh-dep-khong-ty-vet-nhung-ngoc-trinh-khien-nguoi-nhin-ta-hoa-khi-phat-hien-ra-phan-di-dang-nay.html)

VFND_Ac_Fake_35: [Tin tức Việt Nam](http://tinvn.info/ban-trai-yeu-5-nam-chua-mot-lan-doi-hoi-nghi-anh-gay-toi-keo-luon-vao-phong-coi-ao-de-kiem-tra-thi-anh-ap-ung-xin-em-dung-coi-va-su-that-la.htmlhttp://tinvn.info/xe-dang-di-bong-dung-chet-may-thieu-nu-kinh-hai-khi-thao-tung-xe-la-canh-tuong-khong-the-nao-quen.html)

VFND_Ac_Fake_36: [Nhật Kim Anh tiết lộ "thần dược" giúp cô thoát khỏi lưỡi hái tử thần trên máy bay](http://tinvn.info/nhat-kim-anh-tiet-lo-than-duoc-giup-co-thoat-khoi-luoi-hai-tu-than-tren-may-bay.html)

VFND_Ac_Fake_37: [Mặc đồ bơi gợi cảm, Bảo Anh gây bất ngờ khi xăm chữ này lên đùi](http://tinvn.info/mac-do-boi-goi-cam-bao-anh-gay-bat-ngo-khi-xam-chu-nay-len-dui.html)

VFND_Ac_Fake_38: [Hàng ngàn người Hà Nội đứng hình khi chứng kiến bộ trang phục trần da thịt của em gái trẻ đẹp này](http://tinvn.info/hang-ngan-nguoi-ha-noi-dung-hinh-khi-chung-kien-bo-trang-phuc-tran-da-thit-cua-em-gai-tre-dep-nay.html)

VFND_Ac_Fake_39: [Cảm giác như trục quay trái đất sắp gãy khi xem loạt ảnh không thể không gào thét này](http://tinvn.info/cam-giac-nhu-truc-quay-trai-dat-sap-gay-khi-xem-loat-anh-khong-the-khong-gao-thet-nay.html)

VFND_Ac_Fake_40: [Người đàn ông bị “ma dắt đi chơi” cho tới chết ở Quảng Nam?](http://tinvn.info/nguoi-dan-ong-bi-ma-dat-di-choi-cho-toi-chet-o-quang-nam.html)

VFND_Ac_Fake_41: [Nhặt được chiếc hộp kì lạ trên biển, người đàn ông phải vào viện ngay lập tức khi biết danh tính thật của nó](http://tinvn.info/nhat-duoc-chiec-hop-ki-la-tren-bien-nguoi-dan-ong-phai-vao-vien-ngay-lap-tuc-khi-biet-danh-tinh-that-cua-no.html)

VFND_Ac_Fake_42: [Những dấu hiệu nhận biết nhà bạn đang có ma và cách trừ ma quỷ trong nhà](http://tinvn.info/nhung-dau-hieu-nhan-biet-nha-ban-dang-co-ma-va-cach-tru-ma-quy-trong-nha.html)

VFND_Ac_Fake_43: [Bí mật động trời mà không một nhân viên khách sạn nào dám nói cho bạn biết](http://tinvn.info/bi-mat-dong-troi-ma-khong-mot-nhan-vien-khach-san-nao-dam-noi-cho-ban-biet.html)

VFND_Ac_Fake_44: [Bí mật đằng sau chiếc nhẫn trên ngón tay út của Thanh Hằng và Chi Pu](http://tinvn.info/bi-mat-dang-sau-chiec-nhan-tren-ngon-tay-ut-cua-thanh-hang-va-chi-pu.html)

VFND_Ac_Fake_45: [Bé Nhật Lan báo mộng cho người nhà về nghi phạm trước khi bị bắt](http://tinvn.info/be-nhat-lan-bao-mong-cho-nguoi-nha-ve-nghi-pham-truoc-khi-bi-bat.html)

VFND_Ac_Fake_46: [Ao làng bỗng lúc nhúc toàn sinh vật lạ, thò tay sờ vào mới tím mặt sợ hãi khi biết sự thật](http://tinvn.info/ao-lang-bong-luc-nhuc-toan-sinh-vat-la-tho-tay-so-vao-moi-tim-mat-so-hai-khi-biet-su-that.html)

VFND_Ac_Fake_47: [Cậu bé kinh hãi khi thấy chân lúc nhúc hàng triệu sinh vật bấu chặt, cúi xuống phát hiện sự thật bàng hoàng](http://tinvn.info/cau-be-kinh-hai-khi-thay-chan-luc-nhuc-hang-trieu-sinh-vat-bau-chat-cui-xuong-phat-hien-su-that-bang-hoang.html)

VFND_Ac_Fake_48: [Bác sĩ không đầu trước cửa phòng khám khiến cả bệnh viện náo loạn khi biết sự thật](http://tinvn.info/bac-si-khong-dau-truoc-cua-phong-kham-khien-ca-benh-vien-nao-loan-khi-biet-su-that.html)

VFND_Ac_Fake_49: [Sốc với những loại “bùa ngải” có thật dấu hiệu khi bị dính và đây là cách phòng tránh !](http://tinvn.info/soc-voi-nhung-loai-bua-ngai-co-that-dau-hieu-khi-bi-dinh-va-day-la-cach-phong-tranh.html)

VFND_Ac_Fake_50: [Nhặt được xác trăn ven đường, người đàn ông chết sững với thứ trong bụng trăn lâu năm](http://tinvn.info/nhat-duoc-xac-tran-ven-duong-nguoi-dan-ong-chet-sung-voi-thu-trong-bung-tran-lau-nam.html)

VFND_Ac_Fake_51: [Tưởng ổ trứng gà mang về ấp thành con, thanh niên ngay lập tức chuyển nhà chỉ sau 2 tuần](http://tinvn.info/tuong-o-trung-ga-mang-ve-ap-thanh-con-thanh-nien-ngay-lap-tuc-chuyen-nha-chi-sau-2-tuan.html)

VFND_Ac_Fake_52: [Cô gái “tự sướng” 101 lần liên tiếp trong suốt 12 giờ liền và cái kết gây sốc](http://tinvn.info/co-gai-tu-suong-101-lan-lien-tiep-trong-suot-12-gio-lien-va-cai-ket-gay-soc.html)

VFND_Ac_Fake_53: [Cặp đôi chụp 1000 kiểu ảnh chỉ một tư thế trong 3 năm, ai cũng sốc khi biết sự thật](http://tinvn.info/cap-doi-chup-1000-kieu-anh-chi-mot-tu-the-trong-3-nam-ai-cung-soc-khi-biet-su-that.html)

VFND_Ac_Fake_54: [Vác bừa hòn đá về kê bếp, người đàn ông sốc nặng khi được trả 400 triệu chỉ vì bí mật này bên trong](http://tinvn.info/vac-bua-hon-da-ve-ke-bep-nguoi-dan-ong-soc-nang-khi-duoc-tra-400-trieu-chi-vi-bi-mat-nay-ben-trong.html)

VFND_Ac_Fake_55: [Vừa thấy “quái khủng” đen xì lòi ra từ khúc cây, thanh niên vứt vội gỗ quý chạy mất dép chỉ sau 1 giây](http://tinvn.info/vua-thay-quai-khung-den-xi-loi-ra-tu-khuc-cay-thanh-nien-vut-voi-go-quy-chay-mat-dep-chi-sau-1-giay.html)

VFND_Ac_Fake_56: [Phát hoảng vì tiếng rít đinh tai mỗi đêm, chạy ra kêu cứu mới kinh hoàng thấy cảnh tượng đẫm máu chồng đang làm sau vườn](http://tinvn.info/phat-hoang-vi-tieng-rit-dinh-tai-moi-dem-chay-ra-keu-cuu-moi-kinh-hoang-thay-canh-tuong-dam-mau-chong-dang-lam-sau-vuon.html)

VFND_Ac_Fake_57: [Tưởng cả trăm con rắn bò vào nhà trả thù, chàng trai kinh hãi tột độ khi thấy cảnh tượng chết chóc ám ảnh sau đó](http://tinvn.info/tuong-ca-tram-con-ran-bo-vao-nha-tra-thu-chang-trai-kinh-hai-tot-do-khi-thay-canh-tuong-chet-choc-am-anh-sau-do.html)

VFND_Ac_Fake_58: [Dụ em gái cosplay mới quen gửi ảnh trong bồn tắm, chàng trai sốc tận não khi nàng trút bỏ xiêm y](http://tinvn.info/du-em-gai-cosplay-moi-quen-gui-anh-trong-bon-tam-chang-trai-soc-tan-nao-khi-nang-trut-bo-xiem-y.html)

VFND_Ac_Fake_59: [Thời buổi giờ xinh quá cũng là cái tội, như cô gái này chẳng hạn!](http://tinvn.info/thoi-buoi-gio-xinh-qua-cung-la-cai-toi-nhu-co-gai-nay-chang-han.html)

VFND_Ac_Fake_60: [Vợ chết 3 ngày về báo mộng, chồng dỡ trần nhà xuống để rồi sốc ngất khi thấy thứ đó](http://tinvn.info/vo-chet-3-ngay-ve-bao-mong-chong-do-tran-nha-xuong-de-roi-soc-ngat-khi-thay-thu-do.html)

VFND_Ac_Fake_61: [Đêm nào mẹ cũng báo mộng cho con trai và cái kết](http://tinvn.info/dem-nao-me-cung-bao-mong-cho-con-trai-va-cai-ket.html)

VFND_Ac_Fake_62: [Cưới vợ cho con trai, bố mẹ đặt 200 mâm cỗ nhưng không ai tới, thông gia biết được sự thật thì đòi hủy hôn ngay lập tức](http://tinvn.info/cuoi-vo-cho-con-trai-bo-me-dat-200-mam-co-nhung-khong-ai-toi-thong-gia-biet-duoc-su-that-thi-doi-huy-hon-ngay-lap-tuc.html)

VFND_Ac_Fake_63: [Chấp nhận đổ vỏ cho con nhỏ bạn thân và cái kết sốc](http://tinvn.info/chap-nhan-do-vo-cho-con-nho-ban-than-va-cai-ket-soc.html)

VFND_Ac_Fake_64: [Chồng “chôn” chuối xanh và trứng xuống dưới đất cảnh tượng đằng sau khiến vợ kinh hãi](http://tinvn.info/chong-chon-chuoi-xanh-va-trung-xuong-duoi-dat-canh-tuong-dang-sau-khien-vo-kinh-hai.html)

VFND_Ac_Fake_65: [Bạn gái Đạt Cỏ nhận muôn nghìn gạch đá khi bình luận cực sốc thế này ở bức ảnh hở bạo của Ngân 98](http://tinvn.info/ban-gai-dat-co-nhan-muon-nghin-gach-da-khi-binh-luan-cuc-soc-the-nay-o-buc-anh-ho-bao-cua-ngan-98.html)

VFND_Ac_Fake_66: [Sau thời gian dài chữa bệnh, đại gia xấu nhất thế giới Trần Sơn gây sốc nặng với hình ảnh bảnh bao khó tin](http://tinvn.info/sau-thoi-gian-dai-chua-benh-dai-gia-xau-nhat-the-gioi-tran-son-gay-soc-nang-voi-hinh-anh-banh-bao-kho-tin.html)

VFND_Ac_Fake_67: [Hot girl có vòng 1 tự nhiên khủng nhất châu Á phát ngôn gây sốc về lý do không bao giờ mặc hở](http://tinvn.info/hot-girl-co-vong-1-tu-nhien-khung-nhat-chau-a-phat-ngon-gay-soc-ve-ly-do-khong-bao-gio-mac-ho.html)

VFND_Ac_Fake_68: [Mặc đồ không khác gì vải màn lên bar đú đởn, Mon 2k nhận cái kết quá đắng khi phát ngôn câu này](http://tinvn.info/mac-do-khong-khac-gi-vai-man-len-bar-du-don-mon-2k-nhan-cai-ket-qua-dang-khi-phat-ngon-cau-nay.html)

VFND_Ac_Fake_69: [Quán trứng vịt lộn 1 đêm bán 1.000 quả: Khách đến mua sốc nặng khi biết bên trong nồi có…](http://tinvn.info/quan-trung-vit-lon-1-dem-ban-1-000-qua-khach-den-mua-soc-nang-khi-biet-ben-trong-noi-co.html)

VFND_Ac_Fake_70: [Lý do Phi Nhung phải uống thuốc trừ sâu tự tử khiến ai cũng ‘choáng’?](http://tinvn.info/ly-do-phi-nhung-phai-uong-thuoc-tru-sau-tu-tu-khien-ai-cung-choang.html)

VFND_Ac_Fake_71: [Dốc ống điều hòa, rụng tim vì thấy sinh vật bằng cổ tay dài cả mét này trườn ra](http://tinvn.info/doc-ong-dieu-hoa-rung-tim-vi-thay-sinh-vat-bang-co-tay-dai-ca-met-nay-truon-ra.html)

VFND_Ac_Fake_72: [Lấy chồng thực vật, 35 tuổi vẫn còn zin, 1 đêm chăm chồng mệt quá vợ ngủ thiếp đi, lúc tỉnh dậy thì hốt hoảng khi thấy…](http://tinvn.info/lay-chong-thuc-vat-35-tuoi-van-con-zin-1-dem-cham-chong-met-qua-vo-ngu-thiep-di-luc-tinh-day-thi-hot-hoang-khi-thay.html)

VFND_Ac_Fake_73: [Muốn tiền vào như nước, nhớ đừng để thứ này trong ví](http://tinvn.info/muon-tien-vao-nhu-nuoc-nho-dung-de-thu-nay-trong-vi.html)

VFND_Ac_Fake_74: [Chỉ một lần vui quá trớn, thanh niên sùi đầy nốt lạ trên lưng để rồi chết lặng khi biết sự thật đắng ngắt](http://tinvn.info/chi-mot-lan-vui-qua-tron-thanh-nien-sui-day-not-la-tren-lung-de-roi-chet-lang-khi-biet-su-that-dang-ngat.html)

VFND_Ac_Fake_75: [Những dấu hiệu nhận biết nhà bạn đang có ma và cách trừ ma quỷ trong nhà](http://tinvn.info/nhung-dau-hieu-nhan-biet-nha-ban-dang-co-ma-va-cach-tru-ma-quy-trong-nha.html)

VFND_Ac_Fake_76: [Tưởng nhặt được trứng khủng long giữa vườn, mang vào nhà sợ hãi tột độ khi thấy nở trên tay là…](http://tinvn.info/tuong-nhat-duoc-trung-khung-long-giua-vuon-mang-vao-nha-so-hai-tot-do-khi-thay-no-tren-tay-la.html)

VFND_Ac_Fake_77: [Cứ tưởng đào được trứng khủng long, người đàn ông tách đôi mới câm nín vì bên trong thực ra là…](http://tinvn.info/cu-tuong-dao-duoc-trung-khung-long-nguoi-dan-ong-tach-doi-moi-cam-nin-vi-ben-trong-thuc-ra-la.html)

VFND_Ac_Fake_78: [Đêm nào cũng nghe lục đục dưới gầm giường, sợ hãi lật tấm phản phát hiện bí mật kinh hoàng](http://tinvn.info/dem-nao-cung-nghe-luc-duc-duoi-gam-giuong-so-hai-lat-tam-phan-phat-hien-bi-mat-kinh-hoang.html)

VFND_Ac_Fake_79: [Thấy vợ máu me nằm bất động trên sàn, tưởng con gái “xuống tay” hạ sát, lao vào phát hiện sự thật kinh hoàng](http://tinvn.info/thay-vo-mau-me-nam-bat-dong-tren-san-tuong-con-gai-xuong-tay-ha-sat-lao-vao-phat-hien-su-that-kinh-hoang.html)

VFND_Ac_Fake_80: [Rạch đầu rắn mọc lổn nhổn đá dăm là cảnh tượng kinh hoàng không ai muốn chứng kiến quá 5 giây](http://tinvn.info/rach-dau-ran-moc-lon-nhon-da-dam-la-canh-tuong-kinh-hoang-khong-ai-muon-chung-kien-qua-5-giay.html)

VFND_Ac_Fake_81: [Tím mặt bóp bụng trăn khủng quằn quại trên sàn “bơm” ra thứ kinh dị ám ảnh cả gia đình](http://tinvn.info/tim-mat-bop-bung-tran-khung-quan-quai-tren-san-bom-ra-thu-kinh-di-am-anh-ca-gia-dinh.html)

VFND_Ac_Fake_82: [Nếu thấy thứ này thò lên ngoài vườn nhà, đừng chạm vào mà hãy chạy nhanh khi còn có thể](http://tinvn.info/neu-thay-thu-nay-tho-len-ngoai-vuon-nha-dung-cham-vao-ma-hay-chay-nhanh-khi-con-co-the.html)

VFND_Ac_Fake_83: [Vừa rời giường bệnh chưa bao lâu, ai nấy chết ngất khi bắt gặp Trần Sơn đang làm việc kinh dị này](http://tinvn.info/vua-roi-giuong-benh-chua-bao-lau-ai-nay-chet-ngat-khi-bat-gap-tran-son-dang-lam-viec-kinh-di-nay.html)

VFND_Ac_Fake_84: [Khiếp sợ với chiếc mũi biến dạng kinh dị, người đàn ông khiến cả phòng phẫu thuật ám ảnh khi vừa chạm kéo là cảnh tượng…](http://tinvn.info/khiep-so-voi-chiec-mui-bien-dang-kinh-di-nguoi-dan-ong-khien-ca-phong-phau-thuat-am-anh-khi-vua-cham-keo-la-canh-tuong.html)

VFND_Ac_Fake_85: [Vén quần thấy giun bò lúc nhúc trong bắp chân, tới bệnh viện mới ói mửa khi biết sự thật bên trong](http://tinvn.info/ven-quan-thay-giun-bo-luc-nhuc-trong-bap-chan-toi-benh-vien-moi-oi-mua-khi-biet-su-that-ben-trong.html)

VFND_Ac_Fake_86: [Đêm nào cũng thấy vợ biến mất, đặt camera ẩn chồng phát hiện hành động quá kinh hoàng](http://tinvn.info/dem-nao-cung-thay-vo-bien-mat-dat-camera-an-chong-phat-hien-hanh-dong-qua-kinh-hoang.html)

VFND_Ac_Fake_87: [Thích dạng háng check-in cho thoáng, thiếu nữ khiến bạn bè đứng hình khi thấy thứ kinh dị lòi ra](http://tinvn.info/thich-dang-hang-check-in-cho-thoang-thieu-nu-khien-ban-be-dung-hinh-khi-thay-thu-kinh-di-loi-ra.html)

VFND_Ac_Fake_88: [Nhận xăm “chỗ kín” cho thiếu nữ, tái mặt vì thấy điều kinh dị khiến anh thợ muốn hộc máu mồm](http://tinvn.info/nhan-xam-cho-kin-cho-thieu-nu-tai-mat-vi-thay-dieu-kinh-di-khien-anh-tho-muon-hoc-mau-mom.html)

VFND_Ac_Fake_89: [Nghiện xăm mình, thiếu nữ khóc ngất khi nhìn thấy cánh tay mình sau vài ngày đi xóa](http://tinvn.info/nghien-xam-minh-thieu-nu-khoc-ngat-khi-nhin-thay-canh-tay-minh-sau-vai-ngay-di-xoa.html)

VFND_Ac_Fake_90: [Mẹ già báo mộng “nó ăn hết rồi”, con cháu cải mộ sau 3 năm khóc ngất khi thấy cảnh này](http://tinvn.info/me-gia-bao-mong-no-an-het-roi-con-chau-cai-mo-sau-3-nam-khoc-ngat-khi-thay-canh-nay.html)

VFND_Ac_Fake_91: [Hẹn hò người thương nơi sân trường, nam sinh khóc thét cầm dép bỏ chạy khi thấy thứ này lòi ra từ vòng 3 thiếu nữ](http://tinvn.info/hen-ho-nguoi-thuong-noi-san-truong-nam-sinh-khoc-thet-cam-dep-bo-chay-khi-thay-thu-nay-loi-ra-tu-vong-3-thieu-nu.html)

VFND_Ac_Fake_92: [Võ sư 60 tuổi, tay không đánh bại hàng trăm giang hồ Sài Gòn](http://tinvn.info/vo-su-60-tuoi-tay-khong-danh-bai-hang-tram-giang-ho-sai-gon.html)

VFND_Ac_Fake_93: [Bủn rủn chân tay khi lỡ chạm tay vào hàng triệu chiếc răng mọc chi chít trên da thịt người đàn ông](http://tinvn.info/bun-run-chan-tay-khi-lo-cham-tay-vao-hang-trieu-chiec-rang-moc-chi-chit-tren-da-thit-nguoi-dan-ong.html)

VFND_Ac_Fake_94: [Liên tục được con trai báo mộng, bà mẹ kinh hãi khi nhìn thấy cảnh tượng khi thăm mộ con](http://tinvn.info/lien-tuc-duoc-con-trai-bao-mong-ba-me-kinh-hai-khi-nhin-thay-canh-tuong-khi-tham-mo-con.html)

VFND_Ac_Fake_95: [Ai cũng chăm chú tưởng biển số xe có điều gì khủng khiếp, sốc nặng khi biết sự thật lại là…](http://tinvn.info/ai-cung-cham-chu-tuong-bien-so-xe-co-dieu-gi-khung-khiep-soc-nang-khi-biet-su-that-lai-la.html)

VFND_Ac_Fake_96: [Chuyện li kì người phụ nữ cứu rắn hổ chúa và bầy rắn hổ tìm đến nhà để…](http://tinvn.info/chuyen-li-ki-nguoi-phu-nu-cuu-ran-ho-chua-va-bay-ran-ho-tim-den-nha-de.html)

VFND_Ac_Fake_97: [Chỉ vài giây dừng chờ đèn đỏ, người đàn ông này đã khiến cả quốc gia khóc thét khi tìm thấy điểm rùng rợn lấp ló trong áo](http://tinvn.info/chi-vai-giay-dung-cho-den-do-nguoi-dan-ong-nay-da-khien-ca-quoc-gia-khoc-thet-khi-tim-thay-diem-rung-ron-lap-lo-trong-ao.html)

VFND_Ac_Fake_98: [Người cha thú tính mang bệnh HIV vẫn c.ưỡng h.iếp con gái](http://tinvn.info/nguoi-cha-thu-tinh-mang-benh-hiv-van-c-uong-h-iep-con-gai.html) - Mang các thông tin ở file VFND_Ac_Fake_100

VFND_Ac_Fake_99: [Chữa hết bệnh câm cho vợ, người chồng cay đắng nhìn vợ ra đi tìm cuộc sống mới vì lý do tưởng chỉ có trong phim](http://tinvn.info/chua-het-benh-cam-cho-vo-nguoi-chong-cay-dang-nhin-vo-ra-di-tim-cuoc-song-moi-vi-ly-do-tuong-chi-co-trong-phim.html)

VFND_Ac_Fake_100: [YÊU RÂU XANH (P51): Câu chuyện động trời sau tấm ri đô mỏng](https://www.vietgiaitri.com/phap-luat/201304/yeu-rau-xanh-p51-cau-chuyen-dong-troi-sau-tam-ri-do-mong-735408/)

VFND_Ac_Fake_101: [NÓNG : xử phạt 10 đối tượng "bom" hàng "Lợi dụng lòng tốt của các chiến sĩ" Khai bom hàng cho vui](https://mangxahoi.net/nong-xu-phat-10-doi-tuong-bom-hang-loi-dung-long-tot-cua-cac-chien-si-khai-bom-hang-cho-vui/)

VFND_Ac_Fake_102: [Chính thức: Chính sách một vợ được lấy nhiều chồng để giải quyết tình trạng dư thừa nam giới.](http://anninh247.xyz/chinh-thuc-chinh-sach-mot-vo-duoc-lay-nhieu-chong-de-giai-quyet-tinh-trang-du-thua-nam-gioi/)

VFND_Ac_Fake_103: [Tập đoàn lớn mạnh nhất UAE sản xuất, xuất khẩu vaccine COVID-19 mang tên Hayat-Vax](https://web.archive.org/web/20210910162234/https://cand.com.vn/y-te/tap-doan-lon-manh-nhat-uae-san-xuat-xuat-khau-vaccine-covid-19-mang-ten-hayat-vax-i624743/)

VFND_Ac_Fake_104: [Bộ KIT xét nghiệm Covid -19 của Việt Nam sản xuất vừa được Tổ chức Y tế Thế giới chấp thuận](https://web.archive.org/web/20210506030751/https://www.most.gov.vn/vn/tin-tuc/17701/bo-kit-xet-nghiem-covid--19-cua-viet-nam-san-xuat-vua-duoc-to-chuc-y-te-the-gioi-chap-thuan.aspx) - Lý do xem VFND_Ac_Real_124

VFND_Ac_Fake_105: [Pravda: Đặc nhiệm Nga tiêu diệt tay súng bắn tỉa "giỏi nhất thế giới" ở Ukraine](https://doanhnghiepvn.vn/quoc-te/pravda-dac-nhiem-nga-tieu-diet-tay-sung-ban-tia-gioi-nhat-the-gioi-o-ukraine/20220316033244445) - Người được đề cập đến trong bài viết vẫn còn sống, nguồn tin không được kiểm chứng, sai về nguồn thông tin.

VFND_Ac_Fake_106: [Có tin Tổng thống Ukraine Zelensky đang trốn trong Đại sứ quán Mỹ ở Ba Lan](https://vietgiaitri.com/co-tin-tong-thong-ukraine-zelensky-dang-tron-trong-dai-su-quan-my-o-ba-lan-20220306i6342396/) - Nội dung tường thuật lại một sự kiện không có thật trong cuộc xâm lược Ukraine của Nga: "Tổng thống Ukraine bỏ trốn sang Ba Lan"

VFND_Ac_Fake_107: [Tổng thống Ukraine Zelensky đang "trốn" trong Đại sứ quán Mỹ ở Ba Lan](https://danviet.vn/co-tin-tong-thong-ukraine-zelensky-dang-tron-trong-dai-su-quan-my-o-ba-lan-20220305092804117.htm) - Như VFND_Ac_Fake_106

VFND_Ac_Fake_108: [qυên rúт ѕạc đιện тнoạι ĸнỏι ổ cắм, вà мẹ ngấт lịм nнìn тнảм cảnн хảy đến vớι con gáι](https://baophapluat.online/q%cf%85en-ru%d1%82-%d1%95ac-d%ce%b9en-%d1%82%d0%bdoa%ce%b9-k%d0%bdo%ce%b9-o-ca%d0%bc-%d0%b2a-%d0%bce-nga%d1%82-li%d0%bc-n%d0%bdin-%d1%82%d0%bda%d0%bc-can%d0%bd-%d1%85ay-den-vo%ce%b9-con-ga%ce%b9/)

VFND_Ac_Fake_109: [Тáς giả Trường Lâm muốn đưa chữ 4.0 vào dạy THPT, đại học :" con tôi sẽ học khi đủ 5 tuổi !"](https://baophapluat.online/%d1%82a%cf%82-gia-truong-lam-muon-dua-chu-4-0-vao-day-thpt-dai-hoc-con-toi-se-hoc-khi-du-5-tuoi/)

VFND_Ac_Fake_110: [ngнι ngờ vợ léng pнéng lúc мìnн đι công тác dàι нạn nên мớι có вầυ, cнồng ѕững ngườι ĸнι вιếт ѕự тнậт](https://baophapluat.online/ng%d0%bd%ce%b9-ngo-vo-leng-p%d0%bdeng-luc-%d0%bcin%d0%bd-d%ce%b9-cong-%d1%82ac-da%ce%b9-%d0%bdan-nen-%d0%bco%ce%b9-co-%d0%b2a%cf%85-c%d0%bdong-%d1%95ung-nguo%ce%b9-k%d0%bd%ce%b9-%d0%b2%ce%b9e%d1%82/)

VFND_Ac_Fake_111: [MC Lại Văn Sâm đột ngột qua đời ở tuổi 64](https://tingame.info/mc-lai-van-sam-dot-ngot-qua-doi-o-tuoi-64/)

VFND_Ac_Fake_112: [MC Lại Văn Sâm đột ngột qua đời ở tuổi 64](https://nuochoauk.vn/mc-lai-van-sam-dot-ngot-qua-doi-o-tuoi-64.html)

VFND_Ac_Fake_113: [MC Lại Văn Sâm đột ngột qua đời ở tuổi 64 và sự thật chấn động?](https://shopjaxvinhphuc.vn/2021/06/15/mc-lai-van-sam-dot-ngot-qua-doi-o-tuoi-64-va-su-that-chan-dong/)

VFND_Ac_Fake_114: [Gái trẻ đi taxi trả tiền bằng... quần chip](https://danviet.vn/gai-tre-di-taxi-tra-tien-bang-quan-chip-77771003978.htm)

VFND_Ac_Fake_115: [Đàn ông có thể tự sinh con với nhau, không cần nữ giới?](https://tintuconline.com.vn/suc-khoe/dan-ong-co-the-tu-sinh-con-voi-nhau-khong-can-nu-gioi-n-281759.html): Nội dung bài viết nói về thí nghiệm thụ tinh giữa tinh trùng và phôi thai đơn tính, nhưng tiêu đề bài viết có nội dung hoàn toàn khác: đưa ra kết luận theo thì hiện tại, khẳng định "đàn ông có thể tự sinh con với nhau"

VFND_Ac_Fake_116: [Đàn ông cũng có thể sinh con](https://kenh14.vn/gio-day-hai-nguoi-dan-ong-cung-co-the-sinh-con-voi-nhau-khong-can-phu-nu-20160914014702766.chn): Như VFND_Ac_Fake_115

VFND_Ac_Fake_117: [Hai người đàn ông cũng có thể sinh con với nhau](https://hanoimoi.com.vn/ban-in/Khoa-hoc/848142/hai-nguoi-dan-ong-cung-co-the-sinh-con-voi-nhau): Như VFND_Ac_Fake_115

VFND_Ac_Fake_118: [Bỏ vợ già chi 2 tỷ cưới vợ trẻ măng, cυồɴɢ ɴʜiệτ tới nửa đêm tôi ƈăm ʜậɴ trả về](http://anninh247.xyz/bo-vo-gia-chi-2-ty-cuoi-vo-tre-mang-c%cf%85o%c9%b4%c9%a2-%c9%b4%ca%9cie%cf%84-toi-nua-dem-toi-%c6%88am-%ca%9ca%c9%b4-tra-ve/)

VFND_Ac_Fake_119: [Mừng sinh nhậт sếρ, ƙhi thanh тoán hóa ᵭ‌ơn тhì тấт cả ᵭ‌ều cúi ᵭ‌ầu νào ᵭ‌iện тhoại, cậu тhanh niên тrả тiền тhì hôm sau choáng νáng](http://anninh247.xyz/mung-sinh-nha%d1%82-se%cf%81-%c6%99hi-thanh-%d1%82oan-hoa-%e1%b5%ad%e2%80%8con-%d1%82hi-%d1%82a%d1%82-ca-%e1%b5%ad%e2%80%8ceu-cui-%e1%b5%ad%e2%80%8cau-%ce%bdao-%e1%b5%ad%e2%80%8cien-%d1%82hoai-cau)

VFND_Ac_Fake_120: [CCTV: Nga 2 lần yêu cầu HĐBA họp khẩn nhưng bất thành, sẽ nộp bằng chứng "thảm sát Bucha"](https://soha.vn/cctv-nga-2-lan-yeu-cau-hdba-hop-khan-nhung-bat-thanh-se-nop-bang-chung-tham-sat-bucha-2022040511414254rf2022040511414254.htm): Từ 120-122 các tin tức giả về sự kiện "thảm sát Bucha" trong chiến tranh Nga - Ukraine đã được các cơ quan báo chí, tình báo nguồn mở xác minh là tin tức giả, các nội dung được xác minh là giả bao gồm: "Ukraine tự dàn dựng vụ Bucha", "lính Ukraine giết dân Ukraine",...

VFND_Ac_Fake_121: [N̲gh̲i v̲ấn U̲k̲r̲a̲i̲n̲e ᴛ̲ự ᴛh̲ả̲m s̲á̲ᴛ d̲â̲n củ̲a̲ m̲ì̲n̲h: G̲i̲ới lãn̲h̲ đ̲ạo ph̲ư̲ơng T̲â̲y số̲c nặn̲g - N̲ga đ̲ề n̲gh̲ị HĐBA LH̲Q h̲ọp k̲h̲ẩ̲n](http://anninh247.xyz/n%cc%b2gh%cc%b2i-v%cc%b2an-u%cc%b2k%cc%b2r%cc%b2a%cc%b2i%cc%b2n%cc%b2e-%e1%b4%9b%cc%b2u-%e1%b4%9bh%cc%b2a%cc%b2m-s%cc%b2a%cc%b2%e1%b4%9b-d%cc%b2a%cc%b2n-cu%cc%b2a%cc%b2-m%cc%b2i%cc%b2n%cc%b2h-g%cc%b2/), như VFND_Ac_Fake_120

VFND_Ac_Fake_122: [Có phải con gái là người tình kiếp trước của bố? Hiểu thế nào đây](https://lichngaytot.com/tam-linh/con-gai-la-nguoi-tinh-kiep-truoc-cua-bo-564-212420.html) từ VFND_Ac_Fake_122 đến VFND_Ac_Fake_128: dựa trên luận điểm và tiền đề sai - "Con gái là người tình kiếp trước của bố"

VFND_Ac_Fake_123: [Tình cảm giữa bố và con gái tưởng rằng xa cách nhưng lại rất gần](https://tuvanannam.com/tu-van-giao-duc-con-cai/bo-voi-con-gai.html)

VFND_Ac_Fake_124: [Lớn lên, con sẽ lấy một người chồng giống bố](https://blogxcy.wordpress.com/2014/12/22/lon-len-con-se-lay-mot-nguoi-chong-giong-bo/)

VFND_Ac_Fake_125: [Bố và con gái: Tình yêu đến từ kiếp trước?](https://www.webtretho.com/f/chuyen-tinh-yeu/bo-va-con-gai-tinh-yeu-den-tu-kiep-truoc-2480455)

VFND_Ac_Fake_126: [Mẹ và con gái mới đích thực là tình nhân nhiều kiếp](https://www.webtretho.com/f/me-hong-chuyen/me-va-con-gai-moi-dich-thuc-la-tinh-nhan-nhieu-kiep)

VFND_Ac_Fake_127: [Chị Vân ạ, chỉ 1 câu nói “con gái là người tình kiếp trước của bố!” thì chẳng khiến người ta loạn luân được đâu!](https://www.webtretho.com/f/hanh-trinh-lam-me/chi-van-a-chi-1-cau-noi-con-gai-la-nguoi-tinh-kiep-truoc-cua-bo-thi-chang-khien-nguoi-ta-loan-luan-duoc-dau-2481674)

VFND_Ac_Fake_128: [Con Gái Là Tình Nhân Kiếp Trước Của Bố](https://www.webtretho.com/f/sach-truyen-tho/con-gai-la-tinh-nhan-kiep-truoc-cua-bo)

VFND_Ac_Fake_129: [Tin tức Tổng Thống Trump & Q: CANH BÁO!!!! 18/8/2019 Chính phủ Nhật Bản đã quyết định chấm dứt sản xuất và loại bỏ lò vi sóng ở nước này trước cuối năm nay. Tất cả công dân và tổ chức không đáp ứng yê](https://trumpandq.blogspot.com/2021/09/canh-bao-1882019-chinh-phu-nhat-ban.html)

VFND_Ac_Fake_130: [Dân Mỹ tích cóp ve chai bán kiếm tiền, mua hàng sắp ‘hết đát’ để tiết kiệm khi giá cả tăng kỷ lục](http://nhipsongkinhte.toquoc.vn/dan-my-tich-cop-ve-chai-ban-kiem-tien-mua-hang-sap-het-dat-de-tiet-kiem-khi-gia-ca-tang-ky-luc-42022307104038922.htm) - Bài được dịch từ [This region is suffering from some of the highest inflation in America. Here's how locals are surviving - CNN](https://edition.cnn.com/2022/07/28/economy/surviving-second-highest-inflation/index.html) nhưng thay đổi tiêu đề và nội dung để gây hiểu nhầm: từ "Vùng Riverside trong tiểu bang California đang bị ảnh hưởng bởi lạm phát, người dân cố gắng vượt qua thông qua việc kiếm thêm thu nhập và mua đồ được giảm giá" thành "Dân Mỹ phải bán ve chai để kiếm tiền, và mua hàng sắp hết hạn sử dụng vì lạm phát".

VFND_Ac_Fake_131: [Một nցười Ƭrunց ⵕuốc đănց nhữnց bức ảnh nàу lên mạnց weibo và bình luận](https://congtintuc24gio.com/mot-nguoi-trug-quoc-dang-nhung-buc-anh-nay-len-mang-weibo-va-binh-luan/)

VFND_Ac_Fake_132: [Bɑ Lɑn đe Ԁọɑ ѕẽ ƅắṅ tɾả EU bằnց “tất cả ρɦáo tɾonց tɑу”](https://congtintuc24gio.com/ba-lan-de-doa-se-ban-tra-eu-bang-tat-ca-phao-trong-tay/) - Xem [VFND_Ac_Misleading_1](../../Misleading/Article_Contents/README.md), bài viết được dịch sai một cách có định hướng để đưa ra các thông tin sai lệch về việc Ba Lan phản đối EU trong việc chậm chi quỹ tái thiết hậu COVID19-Vũ Hán
